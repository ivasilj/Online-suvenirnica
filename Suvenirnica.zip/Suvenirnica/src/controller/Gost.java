/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import model.Article;
import model.User;
import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

/**
 *
 * @author KORISNIK
 */
public class Gost implements Initializable{
    @FXML
    TableView suveniriTbl;

    @FXML
    TableColumn suveniriID;

    @FXML
    TableColumn suveniriNaziv;

    @FXML
    TableColumn suveniriCijena;

    @FXML
    TableColumn suveniriOpis;
    
    @FXML
    TableColumn suveniriKategorija;
    
    @FXML
    Button nazadBtn;
    
    @FXML
    public void nazad(ActionEvent a){
             Utils u = new Utils();
             u.showNewWindow("login", a);
            }

    
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.suveniriNaziv.setCellValueFactory(new PropertyValueFactory<>("name"));
        this.suveniriOpis.setCellValueFactory(new PropertyValueFactory<>("description"));
        this.suveniriKategorija.setCellValueFactory(new PropertyValueFactory<>("category"));
        this.suveniriCijena.setCellValueFactory(new PropertyValueFactory<>("price"));
        popuniProizvode();
    }
    private void popuniProizvode () {
        ObservableList<Article> articles= (ObservableList<Article>) Article.select();
        this.suveniriTbl.setItems(articles);
    }
    
    
    
    
    
    
   
    
}
