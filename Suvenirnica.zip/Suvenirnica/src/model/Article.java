package model;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.Image;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Article {

    private int ID;
    private String name;
    private String description;
    private Image image;
    private String category;
    private float price;
    


    public Article(int ID, String name, String description, Image image, String category, float price) {
        this.ID = ID;
        this.name = name;
        this.description = description;
        this.image = image;
        this.category = category;
        this.price = price;
        
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    

    public static Article add(Article a) {
        try {
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            if (a.getImage() != null) {
                ImageIO.write(SwingFXUtils.fromFXImage(a.getImage(), null), "jpg", os);
            }
            InputStream fis = new ByteArrayInputStream(os.toByteArray());

            PreparedStatement stmnt = Database.CONNECTION.prepareStatement("INSERT INTO suveniri VALUES (null, ?, ?, ?, ?, ?, ?)", PreparedStatement.RETURN_GENERATED_KEYS);
            stmnt.setString(1, a.getName());
            stmnt.setString(2, a.getDescription());
            stmnt.setBinaryStream(3, fis);
            stmnt.setString(4, a.getCategory());
            stmnt.setDouble(5, a.getPrice());
            stmnt.setInt(6, 1);
            stmnt.executeUpdate();

            ResultSet rs = stmnt.getGeneratedKeys();
            if (rs.next()) {
                a.setID(rs.getInt(1));
            }
            return a;
        } catch (SQLException e) {
            System.out.println("Nisam uspio dodati suvenir: " + e.getMessage());
            return null;
        } catch (IOException e) {
            System.out.println("Nisam uspio dodati suvenir: " + e.getMessage());
            return null;
        }
    }

    public static boolean remove(Article a) {
        try {
            PreparedStatement stmnt = Database.CONNECTION.prepareStatement("DELETE FROM suveniri WHERE id=?");
            stmnt.setInt(1, a.getID());
            stmnt.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.out.println("Nisam uspio pobrisati suvenir: " + e.getMessage());
            return false;
        }
    }

    public static boolean update(Article a) {
        try {
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            if (a.getImage() != null) {
                ImageIO.write(SwingFXUtils.fromFXImage(a.getImage(), null), "jpg", os);
            }
            InputStream fis = new ByteArrayInputStream(os.toByteArray());
            
            PreparedStatement stmnt = Database.CONNECTION.prepareStatement("UPDATE suveniri SET naziv=?,opis=?,kategorija=? ,slika=? ,cijena=? WHERE id=?");
            stmnt.setString(1, a.getName());
            stmnt.setString(2, a.getDescription());
            stmnt.setString(3, a.getCategory());
            stmnt.setBinaryStream(4, fis);
            stmnt.setFloat(5, a.getPrice());
            stmnt.setInt(6, a.getID());
            stmnt.executeUpdate();
            return true;
        } catch (SQLException | IOException e) {
            System.out.println("Nisam uspio urediti suvenir: " + e.getMessage());
            return false;
        }
    }

    public static List<Article> select() {
        ObservableList<Article> articles = FXCollections.observableArrayList();;
        try {
            Statement stmnt = Database.CONNECTION.createStatement();
            ResultSet rs = stmnt.executeQuery("SELECT * FROM suveniri");


            while(rs.next()){
                Image fxSlika = null;
                try {
                    BufferedImage bImage = ImageIO.read(rs.getBinaryStream(4));
                    fxSlika = SwingFXUtils.toFXImage(bImage, null);
                } catch (NullPointerException | IOException ex) {
                    fxSlika = null;
                }

                articles.add(new Article(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        fxSlika,
                        rs.getString(5),
                        rs.getFloat(6)
                ));
            }
            return articles;
        } catch (SQLException e) {
            System.out.println("Nisam uspio izvuci korisnike iz baze: " + e.getMessage());
            return null;
        }
    }
    
    @Override
    public String toString() {
        return this.name;
    }
}
